//Harika Bhogaraju
//1216938606
#include <stdio.h>
#include <stdlib.h>
#include "tcb.h"

	struct first{
		TCB_T* first_element;
	}first;

	TCB_T* newItem() {
		TCB_T* item = (TCB_T*)malloc(sizeof(TCB_T));
		return item;
	}


	void InitQueue(struct first* head) {
		head->first_element = NULL;
	}


	void AddQueue(struct first* head, struct TCB_T* item) {
		if (head->first_element == NULL) {

			head->first_element = item;
			head->first_element->prev = item;
			head->first_element->next = item;
    }
		else {
			struct TCB_T* tail = head->first_element->prev;
			item->next = head->first_element;
			item->prev = tail;
			head->first_element->prev = item;
			tail->next = item;
		}
	}

	TCB_T* DeleteQueue(struct first* head) {
		TCB_T* temp = (TCB_T*)malloc(sizeof(TCB_T));
		temp = head->first_element;

		if (head->first_element != NULL) {
			if (head->first_element->next == NULL) {
				head->first_element = NULL;
			}
			else {
				temp->prev->next = temp->next;
				temp->next->next->prev = temp->prev;
				head->first_element = temp->next;
			}
		}

		return temp;
	}

	void RotateQ(struct first* head) {
		AddQueue(head, DeleteQueue(head));
	}
